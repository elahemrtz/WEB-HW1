package main

import (
	pb "biz-server/bizserver"
	"context"
	"crypto/sha1"
	"database/sql"
	"flag"
	"fmt"
	"log"
	"math/rand"
	"net"
	"time"

	_ "github.com/lib/pq"
	"github.com/redis/go-redis/v9"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

func RandomString(n int) string {
	var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

	s := make([]rune, n)
	for i := range s {
		s[i] = letters[rand.Intn(len(letters))]
	}
	return string(s)
}

func connect() (*sql.DB, error) {
	return sql.Open("postgres", "host=database port=5432 user=username password=password dbname=default_database sslmode=disable")
}

type server struct {
	pb.UnimplementedBizServer
}

var redisClient = redis.NewClient(&redis.Options{
	Addr:     "redis:6379",
	Password: "", // no password set
	DB:       0,  // use default DB
})

var ctx = context.Background()

func auth(key string) bool {
	hash := sha1.Sum([]byte(key))
	val, err := redisClient.Get(ctx, string(hash[:])).Result()
	fmt.Printf("%v", val)
	if err != nil {
		return false
	}
	return true
}
func parseRows(rows *sql.Rows) []*pb.User {
	var users []*pb.User
	if rows == nil {
		return users
	}
	for rows.Next() {
		var id, age int
		var family, name, gender string
		var createdAt string
		_ = rows.Scan(&id, &name, &family, &age, &gender, &createdAt)
		users = append(users, &pb.User{
			Id:        int32(id),
			Name:      name,
			Family:    family,
			Age:       int32(age),
			Gender:    gender,
			CreatedAt: createdAt,
		})
	}
	return users
}
func (s *server) GetUsers(ctx context.Context, in *pb.GetRequest) (*pb.GetResponse, error) {
	if in.MessageId < 0 || in.MessageId%2 == 1 {
		return nil, status.Error(codes.InvalidArgument, "message id must be a non negative even number")
	}
	if !auth(in.AuthKey) {
		return nil, status.Error(codes.Unauthenticated, "unauthorized")
	}
	db, _ := connect()
	defer db.Close()
	rows, _ := db.Query("SELECT * FROM USERS LIMIT 100")
	if in.UserId != nil {
		rows, _ = db.Query("SELECT * FROM USERS WHERE id = $1", *in.UserId)
	}
	return &pb.GetResponse{
		MessageId: in.MessageId + 1,
		Users:     parseRows(rows),
	}, nil
}
func (s *server) GetUsersInjection(ctx context.Context, in *pb.GetRequest2) (*pb.GetResponse, error) {
	if in.MessageId < 0 || in.MessageId%2 == 1 {
		return nil, status.Error(codes.InvalidArgument, "message id must be a non negative even number")
	}
	if !auth(in.AuthKey) {
		return nil, status.Error(codes.Unauthenticated, "unauthorized")
	}
	db, _ := connect()
	defer db.Close()
	rows, _ := db.Query("SELECT * FROM USERS LIMIT 100")
	if in.UserId != nil {
		rows, _ = db.Query("SELECT * FROM USERS WHERE id = " + *in.UserId)
	}
	return &pb.GetResponse{
		MessageId: in.MessageId + 1,
		Users:     parseRows(rows),
	}, nil
}

var (
	port = flag.Int("port", 5062, "The server port")
)

func InsertFake() {
	db, _ := connect()
	defer db.Close()
	genders := []string{"male", "female"}
	for i := 0; i < 200; i++ {
		if _, err := db.Exec("INSERT INTO USERS (name, family, age, sex, createdAt) VALUES ($1, $2, $3, $4, $5);", RandomString(10), RandomString(10), rand.Int()%50, genders[rand.Int()%2], time.Now()); err != nil {
			log.Fatal(err)
		}
	}
}

func main() {
	flag.Parse()
	InsertFake()
	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", *port))
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterBizServer(s, &server{})
	log.Printf("server listening at %v", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}

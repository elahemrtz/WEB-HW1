package main

import (
	pb "auth-server/authserver"
	"context"
	"crypto/sha1"
	"flag"
	"fmt"
	"log"
	"math"
	"math/rand"
	"net"
	"time"

	"github.com/redis/go-redis/v9"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

const (
	p = 23
	g = 5
	a = 6
)

var (
	port = flag.Int("port", 5052, "The server port")
)

type server struct {
	pb.UnimplementedAuthServer
}

func RandomString(n int) string {
	var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

	s := make([]rune, n)
	for i := range s {
		s[i] = letters[rand.Intn(len(letters))]
	}
	return string(s)
}

var redisClient = redis.NewClient(&redis.Options{
	Addr:     "redis:6379",
	Password: "", // no password set
	DB:       0,  // use default DB
})

func (s *server) PqReq(ctx context.Context, in *pb.PqRequest) (*pb.PqResponse, error) {
	if len(in.Nonce) != 20 {
		return nil, status.Error(codes.InvalidArgument, "nonce must be of length 20")
	}
	if in.MessageId < 0 || in.MessageId%2 == 1 {
		return nil, status.Error(codes.InvalidArgument, "message id must be a non negative even number")
	}
	serverNonce := RandomString(20)
	key := sha1.Sum([]byte(in.Nonce + serverNonce))
	redisClient.Set(ctx, string(key[:]), "", 20*time.Minute)
	return &pb.PqResponse{
		Nonce:       in.Nonce,
		ServerNonce: serverNonce,
		MessageId:   in.MessageId + 1,
		P:           p,
		G:           g,
	}, nil
}

func (s *server) DHParamsReq(ctx context.Context, in *pb.DHParamRequest) (*pb.DHParamResponse, error) {
	if len(in.Nonce) != 20 {
		return nil, status.Error(codes.InvalidArgument, "nonce must be of length 20")
	}
	if len(in.ServerNonce) != 20 {
		return nil, status.Error(codes.InvalidArgument, "server nonce must be of length 20")
	}
	if in.MessageId < 0 || in.MessageId%2 == 1 {
		return nil, status.Error(codes.InvalidArgument, "message id must be a non negative even number")
	}
	key := sha1.Sum([]byte(in.Nonce + in.ServerNonce))
	_, err := redisClient.Get(ctx, string(key[:])).Result()
	if err != nil {
		return nil, status.Error(codes.Unauthenticated, "unauthorized")
	}
	secret := int32(math.Remainder(math.Pow(float64(in.A), a), p))
	redisClient.Set(ctx, string(key[:]), secret, 20*time.Minute)
	return &pb.DHParamResponse{
		Nonce:       in.Nonce,
		ServerNonce: in.ServerNonce,
		MessageId:   in.MessageId + 1,
		B:           int32(math.Remainder(math.Pow(g, a), p)),
	}, nil
}
func main() {
	flag.Parse()

	lis, err := net.Listen("tcp", fmt.Sprintf(":%d", *port))
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}
	s := grpc.NewServer()
	pb.RegisterAuthServer(s, &server{})
	log.Printf("server listening at %v", lis.Addr())
	if err := s.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}

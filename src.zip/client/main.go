package main

import (
	"context"
	"flag"
	"log"
	"math"
	"math/rand"
	"time"

	pb "client/authserver"
	pb2 "client/bizserver"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"
)

const (
	a = 15
)

var (
	addr  = flag.String("addr", "localhost:5052", "the address to connect to")
	addr2 = flag.String("addr2", "localhost:5062", "the address to connect to")
)

func RandomString(n int) string {
	var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")

	s := make([]rune, n)
	for i := range s {
		s[i] = letters[rand.Intn(len(letters))]
	}
	return string(s)
}
func main() {
	flag.Parse()
	conn, err := grpc.Dial(*addr, grpc.WithTransportCredentials(insecure.NewCredentials()))
	conn2, err := grpc.Dial(*addr2, grpc.WithTransportCredentials(insecure.NewCredentials()))
	if err != nil {
		log.Fatalf("did not connect: %v", err)
	}
	defer conn.Close()
	defer conn2.Close()
	c2 := pb2.NewBizClient(conn2)
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	c := pb.NewAuthClient(conn)
	r, err := c.PqReq(ctx, &pb.PqRequest{
		Nonce:     RandomString(20),
		MessageId: 0,
	})
	log.Printf("%v", r)
	r2, err := c.DHParamsReq(ctx, &pb.DHParamRequest{
		Nonce:       r.Nonce,
		ServerNonce: r.ServerNonce,
		MessageId:   r.MessageId + 1,
		A:           int32(math.Remainder(math.Pow(float64(r.G), a), float64(r.P))),
	})
	log.Printf("%v", r2)
	id := int32(2)
	r3, err := c2.GetUsers(ctx, &pb2.GetRequest{
		UserId:    &id,
		AuthKey:   r.Nonce + r.ServerNonce,
		MessageId: 0,
	})
	if err != nil {
		log.Fatalf("failed: %v", err)
	}
	log.Printf("%v", r3)
}
